/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package calculadora;

import java.util.Arrays;  //44
import java.util.Collection;  //44
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.RunWith;  //44
import org.junit.runners.Parameterized;  //44
import org.junit.runners.Parameterized.Parameters;
/**
 *
 * @author rober
 */


@RunWith(Parameterized.class)  //44
public class Calculadora4Test {

    //44
    private int num1;
    private int num2;
    private int resul;
    

    
    public Calculadora4Test(int n1, int n2, int r) {  //44  añadidos los parametros en el constructor de la clase test
        this.num1= n1;  //44  Los this.
        this.num2= n2;
        this.resul= r;
    }
    
    
    //44
    @Parameters
    public static Collection<Object[]> numeros(){
        return Arrays.asList(new Object[][]{ {20,10,2}, {30,-2,-15}, {5,2,3}, {55,11,5}});
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of suma method, of class Calculadora.
     */
    //44 Para q no ejecute tests de los de sin parametros   @Test
    public void testSuma() {
        System.out.println("suma");
        Calculadora4 instance = new Calculadora4(10, 20); //null;
        int expResult = 90;
        int result = instance.suma();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of resta method, of class Calculadora.
     */
    //44 Para q no ejecute tests de los de sin parametros   @Test
    public void testResta() {
        System.out.println("resta");
        Calculadora4 instance = null;
        int expResult = 0;
        int result = instance.resta();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of multiplica method, of class Calculadora.
     */
    //44 Para q no ejecute tests de los de sin parametros   @Test
    public void testMultiplica() {
        System.out.println("multiplica");
        Calculadora4 instance = null;
        int expResult = 0;
        int result = instance.multiplica();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    
    //44
    @Test
    public void testDivide4(){
        System.out.println("divideix");
        Calculadora4 instance = new Calculadora4(this.num1, this.num2);
        int division = instance.divide();
        assertEquals(this.resul, division);
    }
    
    
    //44 Para q no ejecute tests de los de sin parametros   @Test
    /*
    public void testDivide() {
        System.out.println("divide");
        
        try{
            Calculadora4 instance = new Calculadora4(4,0);
            int expResult = 0;
            int result = instance.divide();
            assertEquals(expResult, result);
            // TODO review the generated test code and remove the default call to fail.
            fail("Fallo. Debería lanzar una excepción.");
        } catch (ArithmeticException e){
            System.out.println("Correcto. Ha saltado a la excepción.");
        }
    }
    */
    
}
