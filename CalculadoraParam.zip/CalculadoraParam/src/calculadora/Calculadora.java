/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculadora;

/**
 *
 * @author rober
 */

/**
 *
 * @author usuario
 */
public class Calculadora {
    private int num1;
    private int num2;
    
    public Calculadora(int n1, int n2){
        this.num1= n1;
        this.num2= n2;
    }

    public int suma(){
        int result = num1 + num2;
        return result; 
    } 
    
    public int resta(){ 
        int result = num1 - num2;
        return result; 
    } 
    
    public int multiplica() { 
        int result = num1 * num2;
        return result; 
    } 

    public int divide(){ 
        int result = num1 / num2;
        return result; 
}




}
